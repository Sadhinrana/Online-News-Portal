<form action="http://localhost/mvc/Admin/insertCat" method="post">
	<table>
		<tr>
		<td>Category</td>
		<td><input type="text" name="name" required></input></td>
		</tr>
		<tr>
		<td>Title</td>
		<td><input type="text" name="title" required></input></td>
		</tr>
		<tr>
		<td></td>
		<td><input type="submit" value="insert"></input></td>
		</tr>
	</table>
</form>
</article>
