<h2 style="color:#999900;">Hello <?php echo Session::getSession('username');?>, Use the side bar options for inserting, deleting and updating data.</h2> 
</article>
