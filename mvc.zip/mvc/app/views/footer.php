</div>

  <footer class="footeroption">
	  <section class="footerone">
	  <p>S M Sadhin Rana</p>
	  <p>Computer Science & Engineering,</p>
	  <p>Jessore University of Science & Technology</p>
	  
	  </section>
	  <section class="footerone">
		  <p>FB Page: www.facebook.com/albert.sadhin</p>
		  <p>E-mail: smsadhin123@gmail.com</p>
		  <p>Cell: 01738797379 / 01673694943</p>
	  </section>
  </footer>

</body>
</html>