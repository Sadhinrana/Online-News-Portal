
	<div class="left-div">
		<h2>Online Admission</h2>
		<a href="<?php echo SITE_URL; ?>/admissionform">
			<img width="200px" height="60px" src="<?php echo SITE_URL; ?>/public/img/applynow.png" />
		</a>

	</div>
	<div class="right-div">

		<h2>Forgot Admission Roll?<a href=""> Click here</a></h2>

		<h2>Online Admission Guideline</h2>
		<a href="">How to apply online</a>	

		<h2>Download Admission Circular</h2>
		<a href="">Download Admission Circular 2015-16</a>

	</div>




