		</div>
	</div>

	<div class="full_w Top"></div>
	<div class="full_w">
		<div class="center_d">
			<div class="footer">
				<div class="l_footer" >
					<p>&copy; 2015, JUST</p>
				</div>
				<div class="r_footer" >
					<p>Developed by Department of CSE,JUST</p>
				</div>
			</div>
		</div>
	</div>


</body>
</html>
