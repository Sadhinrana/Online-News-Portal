<?php

class circular_model extends Model{

	function __construct() {
        parent::__construct();
    }

}