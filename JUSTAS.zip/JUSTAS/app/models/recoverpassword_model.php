<?php

class recoverpassword_model extends Model{

	function __construct() {
        parent::__construct();
    }
}