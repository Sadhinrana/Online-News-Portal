<?php 
include "controller/Controller.php";

$controller = new Controller();
$controller->Home();
?>