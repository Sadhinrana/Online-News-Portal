<?php 
include "model/Model.php";

class Controller{
	public $model;
	
	public function __construct(){
		$this->model = new Model();
	}
	
	public function Home(){
		$student = $this->model->get_all();
		include "view/Home.php";
	}
}
?>