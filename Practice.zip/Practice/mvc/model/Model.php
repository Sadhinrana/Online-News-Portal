<?php 
include "Database/DB.php";
class Model{
	public function get_all(){
		$sql = "SELECT * FROM student";
		$stmt = DB::prepare($sql);
		$stmt->execute();
		return $stmt->fetchAll();
	}
}
?>