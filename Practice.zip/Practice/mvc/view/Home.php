<?php include "inc/header.php"; ?>

  <table class="tblone">
    <tr>
        <th>No</th>
        <th>Name</th>
        <th>Department</th>
        <th>Age</th>
        <th>Action</th>
    </tr>
<?php 
$i=0;

foreach($student as $value){
	$i++;
?>
    <tr>
        <td><?php echo $i; ?></td>
        <td><?php echo $value['name']; ?></td>
        <td><?php echo $value['department']; ?></td>
        <td><?php echo $value['age']; ?></td>
        <td>
        <a href="<?php echo 'index.php?action=update&id='.$value['id']?>">Edit</a> ||
        <a href="<?php echo 'index.php?action=delete&id='.$value['id']?>" onclick="return confirm('Are you sure want to delete this data?')">Delete</a>
        </td>
    </tr>
<?php } ?>
  </table>

<?php include "inc/footer.php"; ?>