<?php 
include "inc/header.php"; 

spl_autoload_register(function($classes){
	include "Database/".$classes.".php";
});

$student = new Student();
?>

<section class="mainleft">

<?php
if(isset($_POST['submit'])){
	$name = $_POST['name'];
	$department = $_POST['department'];
	$age = $_POST['age'];
	
	$student->setName($name);
	$student->setDepartment($department);
	$student->setAge($age);
	
	if($student->insert()){
		echo "<span class='insert'> Data inserted successfully. </span>";
	}
}

if(isset($_POST['update'])){
	$id = $_POST['id'];
	$name = $_POST['name'];
	$department = $_POST['department'];
	$age = $_POST['age'];
	
	$student->setName($name);
	$student->setDepartment($department);
	$student->setAge($age);
	
	if($student->update($id)){
		echo "<span class='insert'> Data updated successfully. </span>";
	}
}

if(isset($_GET['action']) && $_GET['action']=='delete'){
	$id = (int)$_GET['id'];
	if($student->delete($id)){
		echo "<span class='delete'> Data deleted successfully. </span>";
	}
}	

if(isset($_GET['action']) && $_GET['action']=='update'){
	$id = (int)$_GET['id'];
	$result = $student->getById($id);
?>

<form action="" method="post">
 <table>
	<input type="hidden" name="id" value="<?php echo $result['id']?>"/>
    <tr>
        <td>Name: </td>
        <td><input type="text" name="name" value="<?php echo $result['name']?>"/></td>    
    </tr>

    <tr>
       <td>Department: </td>
        <td><input type="text" name="department" value="<?php echo $result['department']?>"/></td>
    </tr>

    <tr>
      <td>Age: </td>
        <td><input type="text" name="age" value="<?php echo $result['age']?>"/></td>
    </tr>
    <tr>
      <td></td>
        <td>
        <input type="submit" name="update" value="update"/>
        <input type="reset" value="Clear"/>
        </td>
    </tr>
  </table>
</form>

<?php }else{ ?>

<form id="myForm" action="" method="post">
 <table>
    <tr>
        <td>Name: </td>
        <td><input type="text" name="name" placeholder="Your name" required="1"/></td>    
    </tr>

    <tr>
       <td>Department: </td>
        <td><input type="text" name="department" placeholder="Your department" required="1"/></td>
    </tr>

    <tr>
      <td>Age: </td>
        <td><input type="text" name="age" placeholder="Your age" required="1"/></td>
    </tr>
    <tr>
      <td></td>
        <td>
        <input type="submit" name="submit" value="Submit"/>
        <input type="reset" value="Clear" onclick="function(){document.getElementById('myForm').action = 'index.php';} "/>
        </td>
    </tr>
  </table>
</form>

<?php } ?>

</section>



<section class="mainright">
  <table class="tblone">
    <tr>
        <th>No</th>
        <th>Name</th>
        <th>Department</th>
        <th>Age</th>
        <th>Action</th>
    </tr>
<?php 
$i=0;

foreach($student->get_all() as $value){
	$i++;
?>
    <tr>
        <td><?php echo $i; ?></td>
        <td><?php echo $value['name']; ?></td>
        <td><?php echo $value['department']; ?></td>
        <td><?php echo $value['age']; ?></td>
        <td>
        <a href="<?php echo 'index.php?action=update&id='.$value['id']?>">Edit</a> ||
        <a href="<?php echo 'index.php?action=delete&id='.$value['id']?>" onclick="return confirm('Are you sure want to delete this data?')">Delete</a>
        </td>
    </tr>
<?php } ?>
  </table>
</section>

<?php include "inc/footer.php"; ?>